package javabanco.entidade;

import static org.junit.Assert.assertEquals;

import java.util.ArrayList;

import org.junit.Test;

public class ContaCorrenteTest {

	@Test
	public void testSaldo() {
		ContaCorrente cc = new ContaCorrente(1234, "Joao");
		assertEquals(0, cc.get_saldo(), 0);
	}

	@Test
	public void testCredito() {
		ContaCorrente cc = new ContaCorrente(1245, "Pink");
		cc.credito(100);
		assertEquals(100, cc.get_saldo(), 0);
	}

	@Test
	public void testDebito() {
		ContaCorrente cc = new ContaCorrente(1666, "Deus");
		cc.debito(100);
		assertEquals(-100, cc.get_saldo(), 0);
	}

	@Test
	public void testExtrato() {
		ContaCorrente cc = new ContaCorrente(1300, "JEsus");
		cc.credito(100);
		cc.debito(100);
		ArrayList<Float> op = cc.extrato();
		assertEquals(2, op.size());
		assertEquals(100, op.get(0), 0);
		assertEquals(-100, op.get(1), 0);
	}
	
	@Test
	public void testSaldoPequenosFloats() {
		ContaCorrente cc = new ContaCorrente(1400, "Java");
		cc.credito(0.1f);
		cc.credito(0.2f);
		assertEquals(0.3f, cc.get_saldo(), 0.0f);
	}
	
	@Test(expected = IllegalArgumentException.class)
	public void testCreditoValorNegativo() {
		ContaCorrente cc = new ContaCorrente(1239, "Kakaroto");
		cc.credito(-10);		
	}
	
	@Test(expected = IllegalArgumentException.class)
	public void testDebitoValorNegativo() {
		ContaCorrente cc = new ContaCorrente(1230, "Gohan");
		cc.debito(-10);		
	}
	
	@Test
	public void testTransferencia() {
		ContaCorrente cc = new ContaCorrente(1230, "Snow");
		cc.tranferencia(100, cc);
		assertEquals(100, cc.get_saldo(), 0);
	}
	
	@Test
	public void testGetNumero(){
		ContaCorrente cc = new ContaCorrente(1230, "morte");
		assertEquals(1230, cc.get_numero(), 0);
	}
	
	@Test
	public void testGetTitular(){
		ContaCorrente cc = new ContaCorrente(1230, "morte");
		assertEquals("morte", cc.get_titular());
	}

}
