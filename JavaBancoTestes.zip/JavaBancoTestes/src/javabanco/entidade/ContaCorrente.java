package javabanco.entidade;

import java.util.ArrayList;

public class ContaCorrente {
	private float _saldo = 0;
	private ArrayList<Float> _operacoes = new ArrayList<Float>();
	private int _numero = 0;
	private String _titular;
	
	public ContaCorrente(int numero, String titular) {
		_numero = numero;
		_titular = titular;
	}
	
	public float credito(float valor) {
		if (valor <= 0) throw new IllegalArgumentException("O valor da operacao deve ser maior ou igual a zero");
		_saldo += valor;
		_operacoes.add(valor);
		return _saldo;
	}
	
	public float debito(float valor) {
		if (valor <= 0) throw new IllegalArgumentException("O valor da operacao deve ser maior ou igual a zero");
		_saldo -= valor;
		_operacoes.add(-valor);
		return _saldo;
	}
	
	public ArrayList<Float> extrato() {
		return _operacoes;
	}
	
	public float get_saldo(){
		return _saldo;
	}
	
	public int get_numero() {
		return _numero;
	}
	
	public String get_titular() {
		return _titular;
	}
	
	public void tranferencia (float valor, ContaCorrente ccDestino) {
		ccDestino._saldo += valor;
	}
	
}
